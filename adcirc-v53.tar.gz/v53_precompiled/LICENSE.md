# Copyright
The ADCIRC source code is copyrighted, 1994-2016, by:
  * R.A. Luettich, Jr.
  * J.J. Westerink

No part of this code may be reproduced or redistributed without the written permission of the authors.             
